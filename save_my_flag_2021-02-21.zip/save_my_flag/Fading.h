#pragma once

class Fading
{
public:

	Fading();
	void Update();
	void Render();

};