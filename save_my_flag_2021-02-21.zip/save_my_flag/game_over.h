#pragma once

class GameOver
{
public:
	GameOver();
	void Update();
	void Render();

	int randPage;

	int returnButtonState;
	int mainButtonState;



};