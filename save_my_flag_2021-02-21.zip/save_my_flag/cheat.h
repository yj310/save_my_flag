#pragma once

class Cheat
{
public:
	void Update();
};