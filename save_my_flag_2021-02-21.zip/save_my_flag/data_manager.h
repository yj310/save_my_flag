#pragma once

class DataManager
{
public:

};